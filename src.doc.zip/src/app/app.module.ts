import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
// import { MDBBootstrapModule } from 'angular-bootstrap-md'; 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SearchComponent } from './search/search.component';
import { ReSendComponent } from './re-send/re-send.component';
import { HomeComponent } from './home/home.component'
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { APP_BASE_HREF } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import {MatCardModule} from '@angular/material/card'; 
import {MatTooltipModule} from '@angular/material/tooltip';
import {LandingPageComponent} from './landingPage/landingPage.component'
import {MatGridListModule} from '@angular/material/grid-list';
import { AccessDeniedComponent} from './accessDenied/accessDenied.component';

import {
  IgxAvatarModule,
  IgxBadgeModule,
  IgxButtonModule,
  IgxSnackbarModule,
  IgxGridModule,
  IgxIconModule,
  IgxInputGroupModule,
  IgxSwitchModule,
  IgxLayoutModule,
  IgxNavigationDrawerModule,
  IgxRadioModule,
  IgxRippleModule,
  IgxToggleModule

} from "igniteui-angular";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatDialogModule, MatSidenavModule, MatListModule } from "@angular/material";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
//import { ModelComponent } from './modal/modal.component';
import { MatToolbarModule, MatButtonModule, MatCheckboxModule, MatMenuModule } from '@angular/material';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGuard } from './auth.guard';
import {RedirectGuard} from './RedirectGuard';
import { LogoutModelComponent } from './logout-model/logout-model.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { SupportHeaderComponent } from './support-header/support-header.component';
import {ActivatedRouteSnapshot,RouterStateSnapshot} from '@angular/router';

@NgModule({
  declarations: [
    AppComponent,
    SearchComponent,
    ReSendComponent,
    HomeComponent,
    HeaderComponent,
    LandingPageComponent,
    //ModelComponent,
    DashboardComponent,
    SupportHeaderComponent,   
    LogoutModelComponent,
    PageNotFoundComponent,
    AccessDeniedComponent
  ],
  imports: [
    MatGridListModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    IgxAvatarModule,
    IgxBadgeModule,
    IgxButtonModule,
    IgxSnackbarModule,
    IgxGridModule,
    IgxIconModule,
    IgxInputGroupModule,
    IgxSwitchModule,
    BrowserAnimationsModule,
    MatDialogModule,
    NgbModule,
    MatCheckboxModule,
    MatToolbarModule,
    MatButtonModule,
    MatMenuModule,
    MatSidenavModule,
    IgxLayoutModule,
    IgxNavigationDrawerModule,
    IgxRadioModule,
    IgxRippleModule,
    IgxToggleModule,
    MatCardModule,
    MatTooltipModule

  ],
  entryComponents: [ LogoutModelComponent],
  providers: [{ provide: APP_BASE_HREF, useValue: "/iptplssso" }, NgbModule, AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
