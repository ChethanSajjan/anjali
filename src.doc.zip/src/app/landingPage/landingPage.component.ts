import { Component, OnInit, HostListener, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { AuthGuard } from '../auth.guard';
import { ReSendService } from '../re-send.service';
import { DataService } from '../data.service';
import { UserApplicationAccess } from '../models/UserApplicationAccess';
import { UserAppDetails } from '../models/UserApplicationAccess';
import { AppAccessDetails } from '../models/AppAccessDetails';
import { UserRoleDetails } from '../models/UserRoleDetails';
import { UserRole } from '../models/UserRoleDetails';
import { ActivatedRoute, Router } from '@angular/router';
import { UserDetails } from '../models/UserDetails'
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpParams } from '@angular/common/http';

@Component({
    selector: 'app-landingPage',
    templateUrl: './landingPage.component.html',
    styleUrls: ['./landingPage.component.css']
})

export class LandingPageComponent implements OnInit {
    bounce: any;
    
    colSpan = 1;
    saleId = [];
    public userDetails: UserDetails;
    public userApplicationAccess: UserApplicationAccess;
    public appAccessDetails: AppAccessDetails[] = [];
    public userAppDetails: UserAppDetails[] = [];
    public loginAppAccess: AppAccessDetails[] = [];
    public userRoleDetails: UserRoleDetails;
    spinnerProgress: boolean = false;
    errorMessage: String;
    isError: boolean = false;
    public userRoleList: UserRole []= [];
    public  salesId : string;
    


    constructor(@Inject(DOCUMENT) document, private app: AuthGuard, private count: AuthGuard, public reSendService: ReSendService,
    private dataService: DataService,private router: Router,) {

    }

    //ngOnInit() {
    //   
    //}
    async ngOnInit() {
      
    this.userDetails = await this.getUsers(); // 🧙‍♂️
    console.log(" userDetails====:: " + JSON.stringify(this.userDetails));
    this.dataService.setIsLoggedInRole(this.userDetails.userGroup);
    this.dataService.setSalesId(this.userDetails!.salesId);
    this.dataService.setData(this.userDetails);

    console.log(" userDetails===saleId=:: " + JSON.stringify(this.userDetails!.salesId));
     const param = {
        "userSalesId": this.userDetails.salesId
       }
    this.userApplicationAccess = await this.GetUserAppllicationAccessList(param); // 🧙‍♂️ 
         console.log(" User access Landing APpaccess =====:: " + JSON.stringify(this.userApplicationAccess));

     this.userAppDetails=this.userApplicationAccess.applicationsList;
      console.log(" After  User access Landing APpaccess =====:: " + JSON.stringify(this.userAppDetails));
     
    // this.appAccessDetails = await this.GetAppAccessDetails(); // 🧙‍♂️ 
    // console.log(" appAccess Landing APpaccess =====:: " + JSON.stringify(this.appAccessDetails));
    
    }

    public  async   getUsers():  Promise<any> {
      return  this.reSendService.getUserDetails().toPromise();
  }

  public  async   GetUserAppllicationAccessList(param):  Promise<any> {
        return this.reSendService.getUserApplicationAccessDetails(param).toPromise();
    }

    public async  GetAppAccessDetails(): Promise<any> {
        return this.reSendService.getAppAccessDetails().toPromise();
    }

    CallAppURL(appId){
     
      this.dataService.setUserAppId(appId);
      let salesId = this.dataService.getSalesId;
      
      const param = {
        "userId": salesId,
        'applicationId': appId
      }
      this.spinnerProgress = true;
    this.reSendService.getUserRolesDetails(param).subscribe(data => {
      this.spinnerProgress = false;
    if (data) {
      console.log("Landing User Roles Details =====:: " + JSON.stringify(data));
        this.userRoleDetails = data;
        this.userRoleList=this.userRoleDetails.userRoleList;
             console.log("Landing User Roles Details =====:: " + JSON.stringify(this.userRoleList));
          }
    this.dataService.setIsLoggedInRole(this.userRoleList[0].userRole);
    this.router.navigate([`/search`], { state: { data: appId } });
    }, (error) => {
      this.isError = true;
      //this.setTimeout();
      this.errorMessage = "No records found for given input";
      this.spinnerProgress = false;
    });

  }


      public  async   getUserRolesDetails(param):  Promise<any> {
        //return  this.reSendService.getUserRolesDetails(param).toPromise();
        const promise = await this.reSendService.getUserRolesDetails(param).toPromise();
        console.log("Landing User Roles Details =====:: " + JSON.stringify(promise));
        return promise;
    }  

}
