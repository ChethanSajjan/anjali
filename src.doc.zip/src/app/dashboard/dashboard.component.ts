import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from '@angular/router';

//import { MDBBootstrapModule } from 'angular-bootstrap-md';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  @Output() headerEvent = new EventEmitter<string>();
  router: string;
  
  constructor(private dataService: DataService, private _router: Router) {
    this.router = _router.url; 
   }

  
  ngOnInit() {
   // console.log("dashboard 1...");
    this.dataService.getData().subscribe(data => {
     // console.log("dashboard ..." + JSON.stringify(data));
    });
  }
  
}
