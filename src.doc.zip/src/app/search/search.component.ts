import { Component, OnInit } from '@angular/core';
import { ReSendService } from '../re-send.service';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';
import { interval, Observable } from 'rxjs';
import { map } from 'rxjs/operators';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {


  public appId: String;

  constructor(public reSendService: ReSendService, private route: ActivatedRoute, private router: Router,
    private dataService: DataService) { }


  ngOnInit() {
    
    this.appId = window.history.state.data;
    //alert("======Searching======"+this.appId);

    let salesId = this.dataService.getSalesId;
     // alert("======Searching======"+salesId);

      if(this.appId == 'IPTPLS'){
        window.location.href = 'https://importsdev.lowes.com/importPlus1/';
      }else if (this.appId == 'TRFCOP'){
        window.location.href = 'https://importsdev.lowes.com/ipttrfccop/';
      }
     // window.location.href = 'https://www.google.com/'
      //window.location.href = 'https://importsdev.lowes.com/importPlus/';
       
    
  }


}
