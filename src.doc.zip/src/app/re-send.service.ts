import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { environment } from '../environments/environment';
import { LocationStrategy, Location } from '@angular/common';
import { UserDetails } from './models/UserDetails';
import { UserApplicationAccess } from './models/UserApplicationAccess';
import { UserRoleDetails } from './models/UserRoleDetails';
import { AppAccessDetails } from './models/AppAccessDetails';



@Injectable({
  providedIn: 'root'
})
export class ReSendService {
  

  public USERDETAILS_URL = '/getUserDetails';
  public LOGOUT = '/logout';
  public GET_USER_APP_DETAILS = '/getUserApplicationAccessList'; 
  public GET_USER_APP_ROLES_DETAILS = '/getUserRoleDetails'; 

  

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };
  public appPath = ""
  constructor(private http: HttpClient,private locationStrategy: LocationStrategy) { 
    this.appPath = location.origin + this.locationStrategy.getBaseHref();
      console.log("this.appPath service"+this.appPath);
  }

  private extractData(res: Response) {
    let body = res;
    return body || {};
  }

  getUserDetails(): Observable<any> {
   // return this.http.get<UserDetails>(this.appPath + this.USERDETAILS_URL).pipe(catchError(this.handleError));
   // return this.http.get<UserDetails>(this.appPath + this.USERDETAILS_URL).pipe(catchError(this.handleError));
     return this.http.get<UserDetails>("./assets/data/userDetail.json");
    }

  getUserApplicationAccessDetails(param): Observable<any> {
    //return this.http.post(this.appPath + this.GET_USER_APP_DETAILS, param).pipe(catchError(this.handleError));
    return this.http.get<UserApplicationAccess>("./assets/data/applicationAccessList.json",param);
  }

  getAppAccessDetails(): Observable<any> {
    return this.http.get<AppAccessDetails>("./assets/data/AppAccessDetails.json");
  }
  
  logout() {
    //return this.http.get(this.appPath + this.LOGOUT).pipe(catchError(this.handleError));
    //return this.http.get<UserDetails>("./assets/data/userDetail.json");
  }


  getUserRolesDetails(param): Observable<any> {
   // return this.http.post(this.appPath + this.GET_USER_APP_ROLES_DETAILS,param).pipe(catchError(this.handleError));
     return this.http.get<UserRoleDetails>("./assets/data/userRoleDetails.json",param);
  }

  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    //window.alert(errorMessage);
    return throwError(error);
  }


}


