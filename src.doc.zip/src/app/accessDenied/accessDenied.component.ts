import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accessDenied',
  templateUrl:'./accessDenied.component.html',
  styles: []
})
export class AccessDeniedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
