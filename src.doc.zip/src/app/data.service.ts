import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject, Observable } from 'rxjs';
import { UserDetails } from './models/UserDetails';

@Injectable({
  providedIn: 'root'
})
export class DataService {


  private subject = new Subject<UserDetails>();
  data = this.subject.asObservable();

  private headerSubject = new Subject<string>();

  private isReadyOnlyRoleSubject = new Subject<string>();

  constructor() { }

  public setData(data: any) {
    this.subject.next(data);
  }

  clearData() {
    this.subject.next();
  }

  getData() {
    return this.subject.asObservable();
  }

  setHeaderText(headerText: string) {
    this.headerSubject.next(headerText)
  }

  getHeaderText() {
    return this.headerSubject.asObservable();

  }

  private loggedIn: false;

  get isLoggedIn() {
    return this.loggedIn;
  }
  setIsLoggedIn(value) {
    this.loggedIn = value;
  }

  private loggedInRole: string;

  get getLoggedInRole() {
    return this.loggedInRole;
  }
  setIsLoggedInRole(value) {
    this.loggedInRole = value;
  }


  public salesId: string;

  get getSalesId() {
    return this.salesId;
  }
  setSalesId(value) {
    this.salesId = value;
  }

  private userAppId: string;
  
  get getUserAppId () {
    return this.userAppId;
  }
  setUserAppId(value) {
    this.userAppId = value;
  }


}
