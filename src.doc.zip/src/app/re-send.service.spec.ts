import { TestBed } from '@angular/core/testing';

import { ReSendService } from './re-send.service';

describe('ReSendService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ReSendService = TestBed.get(ReSendService);
    expect(service).toBeTruthy();
  });
});
