import { Component, OnInit, ViewChild } from '@angular/core';
import { ReSendService } from '../re-send.service';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../data.service';
import { IgxBannerComponent, IgxGridComponent, IgxSnackbarComponent } from "igniteui-angular";

import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';



@Component({
  selector: 'app-re-send',
  templateUrl: './re-send.component.html',
  styleUrls: ['./re-send.component.scss']
})
export class ReSendComponent implements OnInit {
//  @ViewChild('resendGrid', null) grid: GridComponent;
  @ViewChild("grid", { static: true }) public grid: IgxGridComponent;
  @ViewChild(IgxSnackbarComponent, { static: true }) public snackbar: IgxSnackbarComponent;
 
 
  headerText = 'Re-Trigger PO/BOL Outbound';

  constructor(public restService: ReSendService, private route: ActivatedRoute, 
    private router: Router, private dataService: DataService,
    private modalService: NgbModal) {

  }

  ngOnInit() {
   // this.asnRecords =window.history.state.data;
  }

}

 
  

