import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReSendComponent } from './re-send.component';

describe('ReSendComponent', () => {
  let component: ReSendComponent;
  let fixture: ComponentFixture<ReSendComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReSendComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReSendComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
