import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { UserDetails } from './models/UserDetails'
import { DataService } from './data.service';
import { map, catchError } from 'rxjs/operators';
import { HttpClient, HttpHeaders, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { LocationStrategy, Location } from '@angular/common';
import {AccessDeniedComponent} from './accessDenied/accessDenied.component';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  public appPath = ""
  public USERDETAILS_URL = '/getUserDetails';


  constructor(private userDetails: UserDetails, private dataService: DataService,
    private _router: Router, private http: HttpClient, private locationStrategy: LocationStrategy) {
   // this.appPath = location.origin + this.locationStrategy.getBaseHref();
   
  }
  
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    //let user_role = localStorage.getItem("currentUser");
    let userAppId = this.dataService.getUserAppId;
   // alert("======AuthGuard======"+userAppId); 
    let salesId = this.dataService.getSalesId;
   // alert("======salesId======"+salesId);
    let userRole = this.dataService.getLoggedInRole
   // alert("======userRole======"+userRole);
    console.log("user_role " + userAppId);
    console.log("user_rol salesId" + salesId);
    console.log("user_role  userRole" + userRole);
    if (userRole && next.data.role.includes(userRole)) {
      if (userRole == 'IPTPLS_TRANS_ROLE') {
        this.dataService.setIsLoggedIn(true);
      } else {
        this.dataService.setIsLoggedIn(false);
      }
      console.log("Authorization is success : " + userRole);
      return Promise.resolve(true);
    }
    this._router.navigate(['/404']);
    return Promise.reject(false)
  };
}

