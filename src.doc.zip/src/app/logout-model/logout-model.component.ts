import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ReSendService } from '../re-send.service';
import { DataService } from '../data.service';

@Component({
  selector: 'app-logout-model',
  templateUrl: './logout-model.component.html',
  styleUrls: ['./logout-model.component.css']
})
export class LogoutModelComponent implements OnInit {
  @Input() displayText;
  @Input() title: string;
  @Input() message: string;
  @Input() btnOkText: string;
  @Input() btnCancelText: string;

  constructor(public activeModal: NgbActiveModal, private dataService: DataService, private service: ReSendService) { }

  ngOnInit() {
  }
  public decline() {
    this.activeModal.close(false);
  }

  public accept() {
    localStorage.removeItem("currentUser");
    this.dataService.clearData();
   // this.service.logout().subscribe(data => {
    //  console.log("Log out...");
  //  });
    window.location.href = 'https://lius.myloweslife.com/wamapps/wamlogin/applogout.jsp';
    //this.activeModal.close(true);
  }

  public dismiss() {
    this.activeModal.dismiss();
  }
}
