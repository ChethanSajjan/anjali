import { Injectable } from '@angular/core';
@Injectable({
    providedIn: 'root'
  })

  export class UserAppDetails {
    applicationId: string
    applicationName: string
    
  }
  
export class UserApplicationAccess{
  usersFirstName:string
  usersLastName:string
  salesId:string
  emailId:string
  applicationsList:UserAppDetails[]
}