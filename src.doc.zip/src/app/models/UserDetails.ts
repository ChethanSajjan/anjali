import { Injectable } from '@angular/core';
@Injectable({
    providedIn: 'root'
  })
export class UserDetails {
    displayName: string
    userName: string
    salesId: string
    windowsId: string
    userGroup: string
}