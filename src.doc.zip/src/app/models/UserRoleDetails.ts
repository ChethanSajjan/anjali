import { Injectable } from '@angular/core';
@Injectable({
    providedIn: 'root'
  })

  export class UserRole {
    userRole: string
  }
  
export class UserRoleDetails{

  applicationId:string
  userId:string
  userRoleList:UserRole[]
}