import { Injectable } from '@angular/core';
@Injectable({
    providedIn: 'root'
  })
export class AppAccessDetails {
    appId: string
    appAccess: boolean
    appName: string
   }

   