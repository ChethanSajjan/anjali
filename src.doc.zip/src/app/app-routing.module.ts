import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { SearchComponent } from './search/search.component';
import { ReSendComponent } from './re-send/re-send.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import {LandingPageComponent} from './landingPage/landingPage.component'
import { AuthGuard } from './auth.guard';
import {RedirectGuard} from './RedirectGuard';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AccessDeniedComponent} from './accessDenied/accessDenied.component';

const appRoutes: Routes = [
  {
    path: '',
    redirectTo: '/landingPage',
    pathMatch: 'full'
  },
  {
    path: 'search',
    component: SearchComponent,
    canActivate: [AuthGuard],
    data: {role: ['IPTPLS_TRANS_ROLE', 'IPTPLS_IT_READ_ONLY','IPT_IA_TIER3_ROLE','IPT_PA_TRANS_MGR_ROLE','TRFC_TRANS_ROLE']}
    },
  {
    path: 're-send',
    component: ReSendComponent,
  //  canActivate: [AuthGuard],
    data: {role: 'IPTPLS_TRANS'}
  },
  {
    path: 'landingPage',
    // canActivate: [AuthGuard],
    component: LandingPageComponent
  },
  {
    path: 'accessDenied',
    component: AccessDeniedComponent
  },
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'header',
    component: HeaderComponent
  },
  {
    path: 'dashboard',
    component: DashboardComponent
  },
  { path: '**', component: PageNotFoundComponent }
]

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
