import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { MatMenuTrigger } from '@angular/material';

import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DataService } from '../data.service';
import { UserDetails } from '../models/UserDetails'
import { UserApplicationAccess } from '../models/UserApplicationAccess'
import { Router } from '@angular/router';
import { ReSendService } from '../re-send.service';
import { LogoutModelComponent } from '../logout-model/logout-model.component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  @ViewChild(MatMenuTrigger, { static: false }) trigger: MatMenuTrigger;
  @Input() headerText: string;

  public userDetails: UserDetails;
  public UserApplicationAccess: UserApplicationAccess;

  constructor(private router: Router, private modalService: NgbModal, private dataService: DataService,
    private service: ReSendService) { }
    
    //headerText = "Imports Plus–Alpha";

 ngOnInit() {

      this.dataService.getData().subscribe(user => {
      console.log("Header : " + JSON.stringify(user));
      this.userDetails = user;
    });

    this.dataService.getHeaderText().subscribe(title => {
      console.log(title + 'current title:::::' + JSON.stringify(title));
      this.headerText = title;
    });

  }

  async ngAfterViewInit() {
    this.userDetails = await this.getUsers(); // 🧙‍♂️ 

    console.log(' getUsers===========================' + JSON.stringify(this.userDetails));


  }


  public  async   getUsers():  Promise<any> {
    return  this.service.getUserDetails().toPromise();
}



  setDocTitle(title: string) {
    this.dataService.setHeaderText(title);
  }

  openUserMenu() {
    this.trigger.openMenu();
  }

  logout() {
    const modalRef = this.modalService.open(LogoutModelComponent);
    modalRef.componentInstance.displayText = "Are you sure you want to logout?";
  }

 }

