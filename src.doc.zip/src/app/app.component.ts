import { Component, OnInit } from '@angular/core';
import { UserDetails } from './models/UserDetails'
import { DataService } from './data.service';
import { ReSendService } from './re-send.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'asn-resend';

  unAuthorized: boolean = false;

  notRegistered = "IPTPLS_NOT_REGISTERED";
  transUser = "IPTPLS_TRANS";
  asnResend = "IPTPLS_ASN_RESEND";
  poResend = "IPTPLS_PO_RESEND";
  hasViewAccess: boolean = false;
  hasWriteAccess: boolean = false;

  constructor(private userDetails: UserDetails, private dataService: DataService, private service: ReSendService) { }

  headerText = "Imports Plus–SOS";
  ngOnInit(): void {
    
  }
}
